// script.js - small client-side behaviors
document.getElementById('year').textContent = new Date().getFullYear();

function submitForm(e){
  e.preventDefault();
  const name = document.getElementById('name').value || '';
  alert('Thank you, ' + name.split(' ')[0] + '!\nYour inquiry has been noted (demo).\nWe will contact you shortly.');
  document.getElementById('contactForm').reset();
}
