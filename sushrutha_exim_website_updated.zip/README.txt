Sushrutha Exim World - Demo Website

Files:
- index.html : Main page
- style.css  : Styles
- script.js  : Small JS for form demo and year
- logo.png   : Replace with your logo image (optional)

How to use:
1. Unzip the package.
2. Put your logo as 'logo.png' in the same folder (optional).
3. Open index.html in a browser to preview.
4. To make the contact form work, connect it to a backend or a form service (Formspree, Netlify Forms, etc.)

Contact:
If you want customizations (colors, copy-editing, domain setup, hosting support), tell me which features you want and I will update the site files.
